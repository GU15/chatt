package startsida;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class SelectProfilePic {
    private String filname;
    private ImageIcon imageIcon;
      /*  public void copyFile(String source) {
            String dest = source + " copy";
            try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(source));
                 BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(dest))) {
                int data = bis.read();
                while (data != -1) {
                    bos.write(data);
                    data = bis.read();
                }
                bos.flush();
            } catch (IOException e) {
                System.err.println(e.toString());
            }
        }

       */

    public static void copy(InputStream is, OutputStream os) throws IOException {
        int data = is.read();
        while (data != -1) {
            os.write(data);
            data = is.read();
        }
        os.flush();
    }

    public void zip(File[] files) throws IOException {
        String filename;
        String directon = files[0].getParent();
        String archifname = directon + " /archive.zip";

        //TODO: DETTA FUNKAR INTE
        try (ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(archifname)))) {
            for (int i = 0; i < files.length; i++) {
                File file = files[i];
                try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file))) {
                    filename = file.getName();
                    zos.putNextEntry(new ZipEntry(filename));
                    SelectProfilePic.copy(bis, zos);
                    zos.closeEntry();
                    zos.flush();
                    JFileChooser fileChooser = new JFileChooser();
                    fileChooser.setMultiSelectionEnabled(false);

                    //URL url = null;
                    //url = new URL(filename);
                    imageIcon = new ImageIcon(filename);
                    System.out.println(filename);
                    JOptionPane.showMessageDialog(null,imageIcon);

                } catch (IOException e) {
                    System.err.println("1" + e);
                }
            }
        } catch (IOException e) {
            System.err.println("2" + e);
        }
    }

    public ImageIcon getImageIcon() {
        return imageIcon;
    }

    /*public static void main (String[]args) throws FontFormatException {
        JFrame frame = new JFrame("Create a account");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new CreateNewUser());
        frame.pack();
        frame.setVisible(true);
    }*/
}
