package startsida;

import chattsida.Controller;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StartFrame extends JFrame {
    private Controller controller;
    private JFrame frame;
    private JPanel pnlMain = new JPanel();
    private JPanel pnlProgramName = new JPanel();
    private JLabel lblProgramName = new JLabel("Programmets namn\n\n");
    private JButton btnLogIn = new JButton("Logga in");
    private JButton btnCreateNewUser = new JButton("Registrera ny användare");

    public StartFrame(Controller controller) throws FontFormatException {
        this.controller = controller;

        setBackground(Color.BLACK);
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(600, 500));
        setUpComponents();
        addListeners();

        pack();
        setVisible(true);
    }

    //TODO: HÄR HAR JAG ÄNDRAT
    public void setUpComponents() {
        lblProgramName.setBackground(Color.black);
        pnlProgramName.setBackground(Color.black);
        pnlMain.setBackground(Color.BLACK);
        pnlMain.setBorder(BorderFactory.createTitledBorder("JOIN US"));
        lblProgramName.setFont(new Font("SansSerif", Font.PLAIN, 30));
        lblProgramName.setForeground(Color.BLUE);
        add(pnlProgramName, BorderLayout.NORTH);
        add(lblProgramName);
        add(pnlMain, BorderLayout.SOUTH);
        pnlMain.setLayout(new GridLayout(10, 1));

        pnlMain.add(btnLogIn);
        pnlMain.add(btnCreateNewUser);
    }

    private void addListeners() {
        ActionListener listener = new ButtonActionListeners();
        btnLogIn.addActionListener(listener);
        btnCreateNewUser.addActionListener(listener);
    }

    //TODO: HÄR HAR JAG ÄNDRAT
    class ButtonActionListeners implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == btnLogIn) {
                setVisible(false);
                controller.logIn();
            } else if (e.getSource() == btnCreateNewUser) {
                controller.newUser();
            }
        }
    }
}
