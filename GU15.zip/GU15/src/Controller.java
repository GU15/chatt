import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class Controller {
    private MainFrame view;
    private List<String> contactList;
    private int numOfContacts = 0;
    private String [][] test = {{"Jens","Inloggad"}, {"Olof", "Inloggad"}, {"Heba","Inloggad"}, {"Karl", "Inloggad"}};

    public Controller() {
        view = new MainFrame(this);
        contactList = new ArrayList<>();
        view.updateOnlineTable(test);
    }

    public void addContact(String username) {
        if (!contactList.contains(username)) {
            contactList.add(username);
            numOfContacts++;
        }
        else {
            JOptionPane.showMessageDialog(null, "Användaren finns redan i dina kontakter!");
        }
        view.updateContactTable(getContactsFromList());
    }

    public String[][] getContactsFromList() {
        String[][] twoDimArray = new String[numOfContacts][2];
        for (int i = 0; i < contactList.size(); i++) {
            twoDimArray[i][0] = contactList.get(i);
        }
        return twoDimArray;
    }

    public void changeChat(String username) {
        view.changeChat(username);
    }

    public void startNewConversation(String username) {
        changeChat(username);
        view.addNewConversation(username);
        System.out.println(username);
    }


    public int getNumOfContacts() {
        return numOfContacts;
    }

    public static void main(String[] args) {
        Controller controller = new Controller();
    }

}
