import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class ConversationPanel extends JPanel {
    private Font f = new Font(Font.SANS_SERIF, Font.PLAIN, 16);
    private JTable newMessageTable = new JTable();
    private JList conversationList = new JList();
    private String [] conversations;
    private List<String> conversation = new ArrayList<>();
    private Controller controller;

    public ConversationPanel(Controller controller) {
        this.controller = controller;
        setPreferredSize(new Dimension(230, 440));
        setBorder(BorderFactory.createTitledBorder("Dina konversationer"));
        setUpPanel();

        conversationList.setFont(f);
        conversationList.setFixedCellHeight(25);
        addListener();
    }

    public void setUpPanel() {
        JScrollPane sp = new JScrollPane(conversationList);
        conversationList.setPreferredSize(new Dimension(200, 380));
        conversationList.setLayoutOrientation(JList.HORIZONTAL_WRAP);
        sp.setPreferredSize(new Dimension(210, 400));
        add(sp);
    }

    private void addListener() {
        conversationList.addListSelectionListener(new ListSelectionListener(){
            public void valueChanged(ListSelectionEvent evt) {
                controller.changeChat(String.valueOf(conversationList.getSelectedValue()));
            }
        });
    }

    public void addNewConversation(String username) {
        if (!conversation.contains(username)) {
            conversation.add(username);
        }
        updateConversationList();
    }

    public void updateConversationList() {
        conversations = new String[conversation.size()];
        for (int i = 0; i < conversation.size(); i++) {
            conversations[i] = conversation.get(i);
        }
        conversationList.setListData(conversations);
    }
}
