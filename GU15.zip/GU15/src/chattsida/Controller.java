package chattsida;

import startsida.CreateNewUser;
import startsida.LogInFrame;
import startsida.StartFrame;

import java.awt.*;
import java.util.List;

public class Controller {
    private MainFrame view;
    private StartFrame startFrame;
    private LogInFrame logInFrame;
    private CreateNewUser createNewUser;
    private List<String> contactList;
    private String [][] test = {{"Jens","Inloggad"}, {"Olof", "Inloggad"}, {"Heba","Inloggad"}, {"Karl", "Inloggad"}};
    private String username;

    public Controller() throws FontFormatException {

        startFrame = new StartFrame(this);
        /*view = new MainFrame(this);
        view.setVisible(false);
        logInFrame = new LogInFrame(this);
        logInFrame.setVisible(false);*/
        //contactList = new ArrayList<>();
        //view.updateOnlineTable(test);
    }

    public void logIn() {
        startFrame.setVisible(false);
        logInFrame = new LogInFrame(this);
        logInFrame.setTitle("Logga in");
    }

    public void openChatSite() {
        view = new MainFrame(this);
    }

    public void goBackToStartFrame() {
        startFrame.setVisible(true);
        logInFrame.setVisible(false);
        createNewUser.setVisible(false);
    }

    public void newUser() {
        startFrame.setVisible(false);
        createNewUser = new CreateNewUser(this);
        logInFrame.setTitle("Skapa ny användare");
    }

    public void addContact(String username) {
        contactList.add(username);
        view.updateContactTable(getContactsFromList());
    }

    public String[][] getContactsFromList() {
        String[][] twoDimArray = new String[contactList.size()][2];
        for (int i = 0; i < contactList.size(); i++) {
            twoDimArray[i][0] = contactList.get(i);
        }
        return twoDimArray;
    }

    public void changeChat(String username) {
        view.changeChat(username);
    }

    public void startNewConversation(String username) {
        changeChat(username);
        view.addNewConversation(username);
        /*if (usernames.length == 1) {
            changeChat(username);
            view.addNewConversation(username);
        }
        else {
            for (String s : usernames) {
                groupChat += s + ", ";
            }
            groupChat = groupChat.substring(0, groupChat.lastIndexOf(","));
            view.addNewGroupChat(usernames);
            view.chageGroupChat(groupChat);
        }*/
    }

    public static void main(String[] args) throws FontFormatException {
        Controller controller = new Controller();
    }

}
