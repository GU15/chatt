package chattsida;

import javax.swing.*;
import java.awt.*;

public class MainPanel extends JPanel {
    private ContactPanel contactPanel;
    private ConversationPanel conversationPanel;
    private MessagePanel messagePanel;
    private Controller controller;

    public MainPanel(Controller controller) {
        this.controller = controller;
        setUpPnl();
    }

    private void setUpPnl() {
        conversationPanel = new ConversationPanel(controller);
        messagePanel = new MessagePanel(controller);
        contactPanel = new ContactPanel(controller);
        add(conversationPanel, BorderLayout.WEST);
        add(messagePanel, BorderLayout.CENTER);
        add(contactPanel, BorderLayout.EAST);
        setPreferredSize(new Dimension( 840, 460 ));
    }

    public ContactPanel getContactPanel() {
        return contactPanel;
    }

    public ConversationPanel getConversationPanel() {
        return conversationPanel;
    }

    public MessagePanel getMessagePanel() {
        return messagePanel;
    }

}
