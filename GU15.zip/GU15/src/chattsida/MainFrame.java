package chattsida;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    private MainPanel panel;
    private Controller controller;

    public MainFrame(Controller controller) {
        this.controller = controller;
        setPreferredSize(new Dimension( 840, 470 ));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel = new MainPanel(controller);
        setContentPane(panel);
        pack();
        setVisible(true);
    }

    public void updateContactTable(String [][] stringList) {
        panel.getContactPanel().updateContacts(stringList);
    }

    public void updateOnlineTable(String [][] stringList) {
        panel.getContactPanel().updateOnline(stringList);
    }

    public void changeChat(String username) {
        panel.getMessagePanel().changeChat(username);
    }

    /*public void chageGroupChat(String username) {
        panel.getMessagePanel().changeGroupChat(username);
    }*/

    public void addNewConversation(String username) {
        panel.getConversationPanel().addNewConversation(username);
    }

    /*public void addNewGroupChat(String[] usernames) {
        panel.getConversationPanel().addNewGroupChat(usernames);
    }*/


}
