package chattsida;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ContactPanel extends JPanel {
    private Controller controller;
    private JPanel panel = new JPanel(new GridLayout(2,1));
    private Font f = new Font(Font.SANS_SERIF, Font.BOLD, 16);

    private JButton btnNew = new JButton("Nytt meddelande");

    private JLabel lblContact = new JLabel("Kontakter");
    private JLabel lblOnline = new JLabel("Online");
    private JTable contactsTable = new JTable();
    private JTable onlineTable = new JTable();

    private ContactsTableModel contactsTableModel;
    private OnlineTableModel onlineTableModel;
    private JPanel pnlContacts = new JPanel();
    private JPanel pnlOnline = new JPanel();

    public ContactPanel(Controller controller) {
        this.controller = controller;
        contactsTableModel = new ContactsTableModel();
        onlineTableModel = new OnlineTableModel();
        setPreferredSize(new Dimension(200, 440));
        setBorder(BorderFactory.createTitledBorder("Chatt"));
        setUpComponents();
    }

    public void setUpContacts() {
        contactsTable = new JTable(contactsTableModel);
        contactsTable.setSelectionMode(DefaultListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

        pnlContacts.setPreferredSize(new Dimension(180, 180));
        lblContact.setFont(f);
        pnlContacts.add(lblContact);
        contactsTable.setPreferredSize(new Dimension(170, 140));
        pnlContacts.add(contactsTable);
    }

    public void setUpOnline() {
        onlineTable = new JTable(onlineTableModel);
        onlineTable.setSelectionMode(DefaultListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

        pnlOnline.setPreferredSize(new Dimension(180, 180));
        lblOnline.setFont(f);
        pnlOnline.add(lblOnline);
        onlineTable.setPreferredSize(new Dimension(170, 150));
        pnlOnline.add(onlineTable);
    }

    public void updateContacts(String[][] stringList) {
        contactsTableModel.setRows(stringList.length);
        contactsTableModel.setTableValues(stringList);
        contactsTable.setModel(contactsTableModel);
        contactsTable.repaint();
    }

    public void updateOnline(String[][] stringList) {
        onlineTableModel.setRows(stringList.length);
        onlineTableModel.setTableValues(stringList);
        onlineTable.setModel(onlineTableModel);
        onlineTable.repaint();
    }

    public void setUpComponents() {
        setUpContacts();
        setUpOnline();
        panel.setPreferredSize(new Dimension(190, 370));
        panel.add(pnlContacts);
        panel.add(pnlOnline);
        add(panel, BorderLayout.WEST);

        btnNew.addActionListener(new ButtonListener());
        add(btnNew);
    }

    /** Det går att selecta bårde kontakt och online */

    private class ButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String choice = "";
            int[] rowsOnline = onlineTable.getSelectedRows();
            int[] rowsContact = contactsTable.getSelectedRows();

            for (int value : rowsContact) {
                choice += contactsTable.getValueAt(value, 0);
                choice += " ";
            }

            for (int value : rowsOnline) {
                choice += onlineTable.getValueAt(value, 0);
                choice += " ";
            }
            controller.startNewConversation(choice);

            /*if (!onlineTable.getSelectionModel().isSelectionEmpty() && !contactsTable.getSelectionModel().isSelectionEmpty()) {
                int a = JOptionPane.showConfirmDialog(null, "Vill du skapa en gruppchatt?");
                switch(a) {
                    case 0:
                        System.out.println("gruppchat");
                    case 1:
                        System.out.println(" ej gruppchat");
                    case 2:
                        break;
                }
            }*/

            /*if (!onlineTable.getSelectionModel().isSelectionEmpty()) {
                /*int a = JOptionPane.showConfirmDialog(null, "Vill du skapa en gruppchatt?");
                switch(a) {
                    case 0:
                        System.out.println("gruppchat");
                    case 1:
                        System.out.println(" ej gruppchat");
                    case 2:
                        break;
                }

                controller.startNewConversation((String) onlineTable.getValueAt(onlineTable.getSelectedRow(), onlineTable.getSelectedColumn()));
            }
            else if (!contactsTable.getSelectionModel().isSelectionEmpty()) {
                controller.startNewConversation((String) contactsTable.getValueAt(contactsTable.getSelectedRow(), contactsTable.getSelectedColumn()));
            }*/


        }
    }
}
