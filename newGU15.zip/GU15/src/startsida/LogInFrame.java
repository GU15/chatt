package startsida;
import chattsida.Controller;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LogInFrame extends JFrame {
    private Controller controller;
    private JPanel pnlMain = new JPanel();
    private JPanel pnlUsername = new JPanel();
    private JPanel pnlButtons = new JPanel(new GridLayout(1,2));
    //private JLabel lblProgramName = new JLabel("Programmets namn");
    private JLabel lblUsername = new JLabel("Ange ditt användarnamn");
    private JButton btnOk = new JButton("OK");
    private JButton btnBack = new JButton("BACK");
    private JTextField tfUsername = new JTextField();

    public LogInFrame(Controller controller) {
        this.controller = controller;

        setPreferredSize(new Dimension(530, 180));
        setUpComponents();

        pack();
        setVisible(true);
    }

    public void setUpComponents() {
        pnlMain.setPreferredSize(new Dimension(520, 170));
        pnlUsername.setPreferredSize(new Dimension(260, 80));
        btnBack.setPreferredSize(new Dimension(230, 50));
        btnOk.setPreferredSize(new Dimension(230, 50));
        tfUsername.setPreferredSize(new Dimension(230, 40));

        //lblProgramName.setFont(new Font("SansSerif", Font.PLAIN, 40));
        tfUsername.setFont(new Font("SansSerif", Font.PLAIN, 16));
        lblUsername.setFont(new Font("SansSerif", Font.PLAIN, 20));
        pnlUsername.add(lblUsername);
        pnlUsername.add(tfUsername);
        btnBack.addActionListener(new ButtonListener());
        btnOk.addActionListener(new ButtonListener());

        pnlButtons.add(btnBack);
        pnlButtons.add(btnOk);
        pnlMain.add(pnlUsername);
        pnlMain.add(pnlButtons);
        add(pnlMain, BorderLayout.CENTER);
    }

    private class ButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == btnBack) {
                controller.goBackToStartFrame();
            }
            else {
                JOptionPane.showMessageDialog(null, "Inloggning lyckades! Välkommen " + tfUsername.getText() + "!");
                controller.openChatSite();
            }
        }
    }

    public String getUsername() {
        return tfUsername.getText();
    }
}
