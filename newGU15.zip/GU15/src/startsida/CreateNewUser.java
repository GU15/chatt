package startsida;

import chattsida.Controller;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class CreateNewUser extends JFrame {
    private Controller controller;

    /** ÄNDRAT */

    private JPanel pnlMain = new JPanel();

    private JPanel pnlUsername = new JPanel();
    private JPanel pnlPhoto = new JPanel();
    private JPanel pnlButton = new JPanel(new GridLayout(1,2));

    /***/
    /*private GridLayout layoutLeft = new GridLayout(4, 1,2,2);
    private GridLayout layoutRight = new GridLayout(4, 1,2,2);

    private JPanel bpanel = new JPanel();
    private JPanel paneld = new JPanel();
    private JPanel pnlLeft = new JPanel(layoutLeft);
    private JPanel pnlRight = new JPanel(layoutRight);*/


    private JLabel programName = new JLabel("Program name");
    private JLabel lblUsername = new JLabel("Username: ");
    private JLabel lblImage = new JLabel("Photo: ");

    private JButton btnOk = new JButton("OK");
    private JButton btnBack = new JButton("BACK");
    private JButton btnPhoto = new JButton("Load an image");
    private JTextField tfUsername = new JTextField();

    public CreateNewUser(Controller controller){
        this.controller = controller;
        //setBorder(BorderFactory.createTitledBorder("Create a account"));
        setPreferredSize(new Dimension(360,335));
        setLayout(new BorderLayout());

       /* username.setPreferredSize(new Dimension(200,15));
        photo.setBorder(BorderFactory.createLineBorder(Color.lightGray,1,true));
        photo.setPreferredSize(new Dimension(200,100));
        programName.setFont(new Font("SansSerif", Font.PLAIN, 40));
        programName.setForeground(Color.blue);

        bpanel.setBorder(BorderFactory.createTitledBorder(""));
        bpanel.setBorder(BorderFactory.createTitledBorder(""));

        bpanel.setBackground(Color.green);
        paneld.setBackground(Color.pink);
        pnlLeft.setBackground(Color.pink);
        pnlRight.setBackground(Color.blue);

        add(programName,BorderLayout.NORTH);
        add(paneld,BorderLayout.WEST);
        add(bpanel,BorderLayout.SOUTH);
        paneld.setLayout(new BorderLayout());
        paneld.add(pnlLeft, BorderLayout.WEST);
        paneld.add(pnlRight, BorderLayout.CENTER);
        pnlLeft.add(name);
        pnlLeft.add(image);
        pnlRight.add(username);
        pnlRight.add(photo);
        bpanel.add(back);
        bpanel.add(ok);*/
        setUpComponents();
        addListeners();

        pack();
        setVisible(true);
    }

    public void setUpComponents() {
        pnlUsername.setPreferredSize(new Dimension(350, 50));
        pnlPhoto.setPreferredSize(new Dimension(350, 200));
        lblUsername.setFont(new Font("SansSerif", Font.PLAIN, 18));
        tfUsername.setFont(new Font("SansSerif", Font.PLAIN, 18));
        tfUsername.setPreferredSize(new Dimension(230, 40));

        btnPhoto.setPreferredSize(new Dimension(180, 180));

        btnBack.setPreferredSize(new Dimension(170, 40));
        btnOk.setPreferredSize(new Dimension(170, 40));

        pnlUsername.add(lblUsername);
        pnlUsername.add(tfUsername);
        //pnlUsername.setBackground(Color.pink);

        //pnlPhoto.setBackground(Color.green);
        pnlPhoto.add(btnPhoto);



        pnlButton.add(btnBack);
        pnlButton.add(btnOk);

        pnlMain.add(pnlUsername);
        pnlMain.add(pnlPhoto);
        pnlMain.add(pnlButton);
        add(pnlMain);

    }

    private void addListeners() {
        ActionListener listener = new ButtonActionListeners();

        btnBack.addActionListener(listener);
        btnOk.addActionListener(listener);
        btnPhoto.addActionListener(listener);
    }

    class ButtonActionListeners implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == btnOk) {
                setVisible(false);
                JOptionPane.showMessageDialog(null, "Välkommen " + tfUsername.getText() + "!");
                controller.openChatSite();
            } else if (e.getSource() == btnBack) {
                controller.setVisible("createNewUser", false);
                controller.goBackToStartFrame();
            }
            else if (e.getSource() == btnPhoto){
                /*SelectProfilePic selectProfilePic = new SelectProfilePic();
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setMultiSelectionEnabled(true);
                if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                    File[] files = fileChooser.getSelectedFiles();
                    if (files.length > 0) {
                        try {
                            selectProfilePic.zip(files);
                            btnPhoto.setIcon(selectProfilePic.getImageIcon());
                            //  photo.setIcon(new ImageIcon(String.valueOf(fileChooser.getSelectedFile())));
                        } catch (IOException ex) {
                            System.out.println("3");
                            ex.printStackTrace();
                        }
                    }

                }*/
                /***************ÄNDRAAAA****************/
                JFileChooser file = new JFileChooser();
                file.setCurrentDirectory(new File(System.getProperty("user.home")));
                //filter the files
                FileNameExtensionFilter filter = new FileNameExtensionFilter("*.Images", "jpg","gif","png");
                file.addChoosableFileFilter(filter);
                int result = file.showSaveDialog(null);
                //if the user click on save in Jfilechooser
                if(result == JFileChooser.APPROVE_OPTION){
                    btnPhoto.setText("");
                    File selectedFile = file.getSelectedFile();
                    String path = selectedFile.getAbsolutePath();
                    btnPhoto.setIcon(ResizeImage(path));
                }
                //if the user click on save in Jfilechooser
                else if(result == JFileChooser.CANCEL_OPTION){
                    System.out.println("No File Select");
                }
            }
            else if (e.getSource() == btnOk) {
                setVisible(false);
                //JOptionPane.showMessageDialog(null, "Välkommen " + tfUsername.getText() + "!");
                controller.openChatSite();
            } else if (e.getSource() == btnBack) {
                controller.goBackToStartFrame();
            }
            /*************ÄNDRAAAA******************/
        }
    }

    public ImageIcon ResizeImage(String ImagePath)
    {
        ImageIcon MyImage = new ImageIcon(ImagePath);
        Image img = MyImage.getImage();
        Image newImg = img.getScaledInstance(btnPhoto.getWidth()-50, btnPhoto.getHeight()-50, Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(newImg);
        return image;
    }

    public String getUsername() {
        return tfUsername.getText();
    }
}
