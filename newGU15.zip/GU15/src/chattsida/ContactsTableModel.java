package chattsida;

import javax.swing.table.AbstractTableModel;

public class ContactsTableModel extends AbstractTableModel {
    private final int columns = 2;
    private int rows = 2;
    private String [][] contactStrings = new String[2][5];

    public void setTableValues(String[][] infoStrings) {
        this.contactStrings = infoStrings;
    }

    public int getColumnCount() {
        return columns;
    }

    public int getRowCount() {
        return rows;
    }
    //returnera animalList.size()

    public Object getValueAt(int row, int col) {
        return contactStrings[row][col];
    }

    public void setRows(int rows) {
        this.rows = rows;
    }
}
