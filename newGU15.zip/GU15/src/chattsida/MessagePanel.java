package chattsida;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MessagePanel extends JPanel {
    private Controller controller;
    private Border border = BorderFactory.createLineBorder(Color.lightGray);
    private Font f = new Font(Font.SANS_SERIF, Font.BOLD, 18);
    private JButton btnSend = new JButton("Send");
    private JLabel lblChatWith = new JLabel("Chatt med Jenny", SwingConstants.LEFT);
    private JLabel profile = new JLabel();
    private ImageIcon profilePic = new ImageIcon("image/gubbe.jpg");

    private JPanel pnlMessageSpec = new JPanel();
    private JPanel pnlMessage = new JPanel();
    private JPanel pnlTextArea = new JPanel();

    private JTextField tfConversation = new JTextField();
    private JTextArea taMessage = new JTextArea();

    private JPanel pnlAddToContacts = new JPanel();
    private JLabel lblNotAContact = new JLabel("Lägg till användaren i kontakter");
    private JButton btnAddContact = new JButton("Add");

    private String user = "";

    public MessagePanel(Controller controller) {
        this.controller = controller;
        setPreferredSize(new Dimension(380, 440));
        setBorder(BorderFactory.createTitledBorder("Meddelande"));
        setUpMessageSpec();
        setUpConversation();
        setUpAddToContact();
    }

    public void setUpMessageSpec() {
        profile.setPreferredSize(new Dimension(60, 60));
        pnlMessageSpec.setPreferredSize(new Dimension(340, 70));
        lblChatWith.setPreferredSize(new Dimension(270,40));


        profile.setIcon(profilePic);
        lblChatWith.setFont(f);

        pnlMessageSpec.add(lblChatWith, BorderLayout.WEST);
        pnlMessageSpec.add(profile, BorderLayout.EAST);

        add(pnlMessageSpec);
    }


    public void setUpConversation() {
        JScrollPane sp = new JScrollPane(tfConversation);
        sp.setPreferredSize(new Dimension(350, 220));


        pnlMessage.setPreferredSize(new Dimension(360, 300));
        tfConversation.setPreferredSize(new Dimension(340, 210));
        pnlTextArea.setPreferredSize(new Dimension(350, 70));
        taMessage.setPreferredSize(new Dimension(280, 60));
        btnSend.setPreferredSize(new Dimension(50, 60));

        tfConversation.setEditable(false);
        pnlMessage.add(sp);

        pnlTextArea.setBorder(border);
        pnlTextArea.add(taMessage);
        pnlTextArea.add(btnSend);
        pnlTextArea.setBackground(Color.white);
        pnlMessage.add(pnlTextArea);
        add(pnlMessage);
    }

    private void setUpAddToContact() {
        pnlAddToContacts.setPreferredSize(new Dimension(350, 30));
        btnAddContact.addActionListener(new ButtonListener());
        pnlAddToContacts.add(lblNotAContact);
        pnlAddToContacts.add(btnAddContact);
        add(pnlAddToContacts);
    }

    private class ButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String labelText = lblChatWith.getText();
            String contactName = labelText.substring(labelText.lastIndexOf(" ") + 1);
            controller.addContact(contactName);
        }
    }

    /*public void changeGroupChat(String usernames) {
        user = "group";
        profile.setVisible(false);
        btnAddContact.setEnabled(false);
        lblChatWith.setPreferredSize(new Dimension(320,40));
        lblChatWith.setText("Chatt med " + usernames);
    }*/

    public void changeChat(String username) {
        lblChatWith.setText("Chatt med " + username);
    }

    public String getUser() {
        return user;
    }

    //TODO: FIXA SÅ ATT NÄR MAN TRYCKER PÅ EN GRUPPKONVO SKA NAMNEN DYKA UPP OCH INTE NAMNET GRUPPCHATT
}
